#!/usr/bin/env python3
"""
Script to remove all comments from JavaScript/JSX and CSS files.
Usage: python remove_comments.py [--dry-run] [--verbose]
"""

import os
import re
import sys
from pathlib import Path

DRY_RUN = '--dry-run' in sys.argv
VERBOSE = '--verbose' in sys.argv

SRC_DIR = Path(__file__).parent / 'src'

JS_EXTENSIONS = {'.js', '.jsx', '.ts', '.tsx', '.mjs'}
CSS_EXTENSIONS = {'.css', '.scss', '.sass', '.less'}
SKIP_DIRS = {'node_modules', 'dist', 'build', '.git', '.next'}


def remove_js_comments(content: str) -> str:
    """Remove comments from JavaScript/JSX/TypeScript content."""
    result = []
    i = 0
    n = len(content)
    
    while i < n:
        # String literals - preserve content
        if content[i] in '"\'`':
            quote = content[i]
            result.append(content[i])
            i += 1
            
            if quote == '`':  # Template literal
                while i < n:
                    if content[i] == '\\' and i + 1 < n:
                        result.append(content[i:i+2])
                        i += 2
                    elif content[i:i+2] == '${':
                        result.append(content[i:i+2])
                        i += 2
                        brace_count = 1
                        while i < n and brace_count > 0:
                            if content[i] == '{':
                                brace_count += 1
                            elif content[i] == '}':
                                brace_count -= 1
                            result.append(content[i])
                            i += 1
                    elif content[i] == '`':
                        result.append(content[i])
                        i += 1
                        break
                    else:
                        result.append(content[i])
                        i += 1
            else:  # Regular string
                while i < n:
                    if content[i] == '\\' and i + 1 < n:
                        result.append(content[i:i+2])
                        i += 2
                    elif content[i] == quote:
                        result.append(content[i])
                        i += 1
                        break
                    else:
                        result.append(content[i])
                        i += 1
        
        # JSX comment {/* ... */}
        elif content[i:i+3] == '{/*':
            i += 3
            while i < n - 1 and content[i:i+2] != '*/':
                i += 1
            i += 2
            # Skip closing brace
            while i < n and content[i] in ' \t':
                i += 1
            if i < n and content[i] == '}':
                i += 1
        
        # Single-line comment
        elif content[i:i+2] == '//':
            while i < n and content[i] != '\n':
                i += 1
        
        # Multi-line comment
        elif content[i:i+2] == '/*':
            i += 2
            while i < n - 1 and content[i:i+2] != '*/':
                i += 1
            i += 2
        
        else:
            result.append(content[i])
            i += 1
    
    # Clean up multiple empty lines
    text = ''.join(result)
    text = re.sub(r'\n\s*\n\s*\n+', '\n\n', text)
    return text


def remove_css_comments(content: str) -> str:
    """Remove comments from CSS content."""
    result = []
    i = 0
    n = len(content)
    
    while i < n:
        # String literals
        if content[i] in '"\'':
            quote = content[i]
            result.append(content[i])
            i += 1
            while i < n:
                if content[i] == '\\' and i + 1 < n:
                    result.append(content[i:i+2])
                    i += 2
                elif content[i] == quote:
                    result.append(content[i])
                    i += 1
                    break
                else:
                    result.append(content[i])
                    i += 1
        
        # Comment
        elif content[i:i+2] == '/*':
            i += 2
            while i < n - 1 and content[i:i+2] != '*/':
                i += 1
            i += 2
        
        else:
            result.append(content[i])
            i += 1
    
    text = ''.join(result)
    text = re.sub(r'\n\s*\n\s*\n+', '\n\n', text)
    return text


def get_files_to_process(directory: Path):
    """Get all files to process recursively."""
    files = []
    for root, dirs, filenames in os.walk(directory):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        for filename in filenames:
            ext = Path(filename).suffix.lower()
            if ext in JS_EXTENSIONS or ext in CSS_EXTENSIONS:
                files.append(Path(root) / filename)
    return files


def process_file(filepath: Path) -> dict:
    """Process a single file."""
    ext = filepath.suffix.lower()
    content = filepath.read_text(encoding='utf-8')
    
    if ext in JS_EXTENSIONS:
        new_content = remove_js_comments(content)
    elif ext in CSS_EXTENSIONS:
        new_content = remove_css_comments(content)
    else:
        return {'changed': False}
    
    changed = content != new_content
    removed_bytes = len(content) - len(new_content)
    
    if changed and not DRY_RUN:
        filepath.write_text(new_content, encoding='utf-8')
    
    return {
        'changed': changed,
        'removed_bytes': removed_bytes,
        'original_size': len(content)
    }


def main():
    print('🧹 Comment Remover Script')
    print('=' * 26)
    
    if DRY_RUN:
        print('📋 DRY RUN MODE - No files will be modified\n')
    else:
        print('⚠️  LIVE MODE - Files will be modified\n')
    
    if not SRC_DIR.exists():
        print(f'❌ Source directory not found: {SRC_DIR}')
        sys.exit(1)
    
    files = get_files_to_process(SRC_DIR)
    print(f'📁 Found {len(files)} files to process\n')
    
    total_changed = 0
    total_bytes_removed = 0
    changed_files = []
    
    for filepath in files:
        rel_path = filepath.relative_to(Path(__file__).parent)
        result = process_file(filepath)
        
        if result['changed']:
            total_changed += 1
            total_bytes_removed += result['removed_bytes']
            changed_files.append({
                'path': str(rel_path),
                'removed_bytes': result['removed_bytes'],
                'original_size': result['original_size']
            })
            
            if VERBOSE:
                print(f"✓ {rel_path} (-{result['removed_bytes']} bytes)")
    
    print('\n📊 Summary')
    print('-' * 10)
    print(f'Files processed: {len(files)}')
    print(f'Files with comments removed: {total_changed}')
    print(f'Total bytes removed: {total_bytes_removed}')
    
    if changed_files and not VERBOSE:
        print('\n📝 Modified files:')
        for f in changed_files:
            pct = (f['removed_bytes'] / f['original_size']) * 100
            print(f"   {f['path']} (-{f['removed_bytes']} bytes, {pct:.1f}%)")
    
    if DRY_RUN and total_changed > 0:
        print('\n💡 Run without --dry-run to apply changes')
    
    print('\n✅ Done!')


if __name__ == '__main__':
    main()
