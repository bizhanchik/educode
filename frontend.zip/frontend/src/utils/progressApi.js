

import { apiRequest } from './apiClient.js';

export const progressApi = {
  
  getProgress: (params = {}) => {
    const queryString = new URLSearchParams(params).toString();
    return apiRequest(`/progress?${queryString}`);
  },

  getUserProgress: (userId) => {
    return apiRequest(`/progress/user/${userId}/summary`);
  },

  getLessonProgress: (userId, lessonId) => {
    return apiRequest(`/progress?user_id=${userId}&lesson_id=${lessonId}`);
  },

  createProgress: (data) => {
    return apiRequest('/progress', {
      method: 'POST',
      body: data,
    });
  },

  updateProgress: (progressId, data) => {
    return apiRequest(`/progress/${progressId}`, {
      method: 'PUT',
      body: data,
    });
  },

  getLessonStats: (lessonId) => {
    return apiRequest(`/progress/lesson/${lessonId}/stats`);
  },
};
