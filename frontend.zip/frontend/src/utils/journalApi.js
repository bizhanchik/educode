

import { apiRequest } from './apiClient.js';

export const journalApi = {
  
  getEntries: (params = {}) => {
    const queryString = new URLSearchParams(params).toString();
    return apiRequest(`/journal?${queryString}`);
  },

  getEntry: (userId, lessonId) => {
    return apiRequest(`/journal?user_id=${userId}&lesson_id=${lessonId}`);
  },

  createEntry: (data) => {
    return apiRequest('/journal', {
      method: 'POST',
      body: data,
    });
  },

  updateEntry: (entryId, data) => {
    return apiRequest(`/journal/${entryId}`, {
      method: 'PUT',
      body: data,
    });
  },

  getCourseJournal: (userId, courseId) => {
    return apiRequest(`/journal/user/${userId}/course/${courseId}`);
  },

  getLessonStats: (lessonId) => {
    return apiRequest(`/journal/lesson/${lessonId}/stats`);
  },
};
