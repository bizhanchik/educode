

import { apiRequest } from './apiClient.js';

export const usersApi = {
  
  getUsers: (params = {}) => {
    const queryString = new URLSearchParams(params).toString();
    return apiRequest(`/users?${queryString}`);
  },

  getUser: (userId) => {
    return apiRequest(`/users/${userId}`);
  },

  createUser: (data) => {
    return apiRequest('/users', {
      method: 'POST',
      body: data,
    });
  },

  updateUser: (userId, data) => {
    return apiRequest(`/users/${userId}`, {
      method: 'PUT',
      body: data,
    });
  },

  deleteUser: (userId) => {
    return apiRequest(`/users/${userId}`, {
      method: 'DELETE',
    });
  },
};
