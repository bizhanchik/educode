import { apiRequest } from "./apiClient.js";

export const practiceApi = {
  
  executeCode: async (code, language = "python") => {
    return apiRequest("/code/execute", {
      method: "POST",
      body: { code, language },
    });
  },

  submitPractice: async (lessonId, practiceData) => {
    return apiRequest(`/code/lessons/${lessonId}/practice/submit`, {
      method: "POST",
      body: {
        lesson_id: lessonId,
        ...practiceData,
      },
    });
  },

  getPracticeResults: async (lessonId) => {
    return apiRequest(`/code/lessons/${lessonId}/practice/results`, {
      method: "GET",
    });
  },

  runTests: async (taskId, code, language = "python") => {
    return apiRequest(`/code/tasks/${taskId}/run-tests`, {
      method: "POST",
      body: { code, language },
    });
  },
};

