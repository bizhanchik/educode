

import { apiRequest } from './apiClient.js';

export const notificationsApi = {
  
  getNotifications: (userId, readStatus = null, params = {}) => {
    const queryParams = { user_id: userId, ...params };
    if (readStatus !== null) {
      queryParams.read = readStatus;
    }
    const queryString = new URLSearchParams(queryParams).toString();
    return apiRequest(`/notifications?${queryString}`);
  },

  createNotification: (data) => {
    return apiRequest('/notifications', {
      method: 'POST',
      body: data,
    });
  },

  markAsRead: (notificationId) => {
    return apiRequest(`/notifications/${notificationId}/read`, {
      method: 'PUT',
    });
  },

  deleteNotification: (notificationId) => {
    return apiRequest(`/notifications/${notificationId}`, {
      method: 'DELETE',
    });
  },

  getUnreadCount: (userId) => {
    return apiRequest(`/notifications/user/${userId}/unread-count`);
  },
};
