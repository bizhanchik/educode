import { apiRequest } from "./apiClient.js";

export const testsApi = {
  
  getRandomQuestions: async (lessonId, count = 12) => {
    return apiRequest(`/tests/lessons/${lessonId}/questions?count=${count}`, {
      method: "GET",
    });
  },

  submitTest: async (lessonId, testData) => {
    return apiRequest(`/tests/lessons/${lessonId}/submit`, {
      method: "POST",
      body: {
        lesson_id: lessonId,
        attempts: testData.attempts || [],
        time_taken_seconds: testData.time_taken_seconds || 0,
        started_at: testData.started_at,
      },
    });
  },

  getTestResults: async (lessonId) => {
    return apiRequest(`/tests/lessons/${lessonId}/results`, {
      method: "GET",
    });
  },
};

