import { apiRequest } from "./apiClient.js";

export const lessonProgressApi = {
  
  getLessonStatus: async (lessonId) => {
    return apiRequest(`/lessons/${lessonId}/status`, {
      method: "GET",
    });
  },

  getNextLesson: async (lessonId) => {
    return apiRequest(`/lessons/${lessonId}/next`, {
      method: "GET",
    });
  },
};

