

import { apiRequest } from './apiClient.js';

export const groupsApi = {
  
  getGroups: (params = {}) => {
    const queryParams = new URLSearchParams();
    
    Object.keys(params).forEach(key => {
      const value = params[key];
      if (value !== undefined && value !== null) {
        if (typeof value === 'boolean') {
          queryParams.append(key, value.toString());
        } else {
          queryParams.append(key, String(value));
        }
      }
    });
    const queryString = queryParams.toString();
    console.log('[groupsApi] getGroups query string:', queryString);
    return apiRequest(`/groups?${queryString}`);
  },

  getGroup: (groupId, includeUsers = false) => {
    return apiRequest(`/groups/${groupId}?include_users=${includeUsers}`);
  },

  createGroup: (data) => {
    return apiRequest('/groups', {
      method: 'POST',
      body: data,
    });
  },

  updateGroup: (groupId, data) => {
    return apiRequest(`/groups/${groupId}`, {
      method: 'PUT',
      body: data,
    });
  },

  deleteGroup: (groupId) => {
    return apiRequest(`/groups/${groupId}`, {
      method: 'DELETE',
    });
  },
};
