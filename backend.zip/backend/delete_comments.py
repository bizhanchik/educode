#!/usr/bin/env python3
"""
Script to delete comments from Python files in the backend folder.

Usage:
    python delete_comments.py [path]           # Preview changes (dry run)
    python delete_comments.py [path] --apply   # Apply changes
    python delete_comments.py --help           # Show help

If no path is provided, it defaults to the current directory.
"""

import os
import re
import sys
import argparse
import tokenize
import io
from pathlib import Path


def remove_comments_from_code(source_code: str) -> str:
    """
    Remove comments from Python source code while preserving strings and functionality.
    
    Handles:
    - Single-line comments (#)
    - Standalone multi-line docstrings (''' or \""")
    - Inline comments
    
    Preserves:
    - Strings that look like comments
    - Shebang lines (#!/usr/bin/env python)
    - Type hints and annotations
    """
    result_lines = []
    lines = source_code.split('\n')
    
    in_multiline_string = False
    multiline_quote = None
    multiline_is_docstring = False
    multiline_start_line = 0
    
    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()
        
        # Handle multi-line strings/docstrings
        if in_multiline_string:
            if multiline_quote in line:
                in_multiline_string = False
                if not multiline_is_docstring:
                    # Keep non-docstring multi-line strings
                    pass
                i += 1
                continue
            else:
                if not multiline_is_docstring:
                    result_lines.append(line)
                i += 1
                continue
        
        # Check for start of multi-line docstring
        if stripped.startswith('"""') or stripped.startswith("'''"):
            quote = '"""' if stripped.startswith('"""') else "'''"
            # Check if it ends on the same line
            rest = stripped[3:]
            if quote in rest:
                # Single-line docstring - skip it (it's a comment)
                i += 1
                continue
            else:
                # Multi-line docstring starts
                in_multiline_string = True
                multiline_quote = quote
                multiline_is_docstring = True
                multiline_start_line = i
                i += 1
                continue
        
        # Preserve shebang
        if i == 0 and stripped.startswith('#!'):
            result_lines.append(line)
            i += 1
            continue
        
        # Skip pure comment lines
        if stripped.startswith('#'):
            i += 1
            continue
        
        # Handle inline comments
        new_line = remove_inline_comment(line)
        
        # Only add non-empty lines or lines that were originally non-empty
        if new_line.strip() or not stripped:
            result_lines.append(new_line.rstrip())
        
        i += 1
    
    return '\n'.join(result_lines)


def remove_inline_comment(line: str) -> str:
    """
    Remove inline comments from a line while preserving strings.
    """
    result = []
    in_string = False
    string_char = None
    i = 0
    
    while i < len(line):
        char = line[i]
        
        if in_string:
            result.append(char)
            if char == '\\' and i + 1 < len(line):
                # Escape sequence
                result.append(line[i + 1])
                i += 2
                continue
            if char == string_char:
                in_string = False
                string_char = None
        else:
            if char in ('"', "'"):
                # Check for triple quotes
                if line[i:i+3] in ('"""', "'''"):
                    # Find end of triple-quoted string on same line
                    quote = line[i:i+3]
                    end_pos = line.find(quote, i + 3)
                    if end_pos != -1:
                        result.append(line[i:end_pos+3])
                        i = end_pos + 3
                        continue
                    else:
                        # Multi-line string, keep rest of line
                        result.append(line[i:])
                        break
                else:
                    in_string = True
                    string_char = char
                    result.append(char)
            elif char == '#':
                # Found comment, stop here
                break
            else:
                result.append(char)
        
        i += 1
    
    return ''.join(result)


def process_file(filepath: Path, apply: bool = False) -> tuple[bool, int, int]:
    """
    Process a single Python file to remove comments.
    
    Returns:
        tuple: (changed: bool, original_lines: int, new_lines: int)
    """
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            original_content = f.read()
    except (UnicodeDecodeError, PermissionError) as e:
        print(f"  ⚠️  Skipping {filepath}: {e}")
        return False, 0, 0
    
    original_lines = len(original_content.split('\n'))
    new_content = remove_comments_from_code(original_content)
    new_lines = len(new_content.split('\n'))
    
    changed = original_content != new_content
    
    if changed and apply:
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(new_content)
    
    return changed, original_lines, new_lines


def find_python_files(directory: Path, exclude_patterns: list[str] = None) -> list[Path]:
    """
    Find all Python files in the directory, excluding specified patterns.
    """
    if exclude_patterns is None:
        exclude_patterns = [
            '__pycache__',
            '.git',
            'venv',
            '.venv',
            'env',
            '.env',
            'node_modules',
            'migrations',
            'alembic/versions',
        ]
    
    python_files = []
    
    for root, dirs, files in os.walk(directory):
        # Filter out excluded directories
        dirs[:] = [d for d in dirs if not any(
            pattern in os.path.join(root, d) for pattern in exclude_patterns
        )]
        
        for file in files:
            if file.endswith('.py'):
                python_files.append(Path(root) / file)
    
    return sorted(python_files)


def main():
    parser = argparse.ArgumentParser(
        description='Remove comments from Python files',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python delete_comments.py                    # Preview changes in current directory
  python delete_comments.py ./app              # Preview changes in ./app directory
  python delete_comments.py ./app --apply      # Apply changes to ./app directory
  python delete_comments.py file.py --apply    # Apply changes to a single file
        """
    )
    
    parser.add_argument(
        'path',
        nargs='?',
        default='.',
        help='Path to Python file or directory (default: current directory)'
    )
    
    parser.add_argument(
        '--apply',
        action='store_true',
        help='Apply changes (without this flag, only preview is shown)'
    )
    
    parser.add_argument(
        '--exclude',
        nargs='+',
        default=[],
        help='Additional patterns to exclude'
    )
    
    args = parser.parse_args()
    
    target_path = Path(args.path).resolve()
    
    if not target_path.exists():
        print(f"❌ Error: Path '{target_path}' does not exist")
        sys.exit(1)
    
    # Determine files to process
    if target_path.is_file():
        if not target_path.suffix == '.py':
            print(f"❌ Error: '{target_path}' is not a Python file")
            sys.exit(1)
        python_files = [target_path]
    else:
        python_files = find_python_files(target_path, args.exclude)
    
    if not python_files:
        print(f"No Python files found in '{target_path}'")
        sys.exit(0)
    
    # Process files
    mode = "APPLYING" if args.apply else "PREVIEW (dry run)"
    print(f"\n{'='*60}")
    print(f"🐍 Python Comment Remover - {mode}")
    print(f"{'='*60}")
    print(f"Target: {target_path}")
    print(f"Files found: {len(python_files)}")
    print(f"{'='*60}\n")
    
    total_changed = 0
    total_lines_removed = 0
    
    for filepath in python_files:
        relative_path = filepath.relative_to(target_path) if target_path.is_dir() else filepath.name
        changed, original, new = process_file(filepath, apply=args.apply)
        
        if changed:
            total_changed += 1
            lines_removed = original - new
            total_lines_removed += lines_removed
            status = "✏️  Modified" if args.apply else "📝 Would modify"
            print(f"{status}: {relative_path} ({lines_removed:+d} lines)")
    
    # Summary
    print(f"\n{'='*60}")
    print("📊 Summary")
    print(f"{'='*60}")
    print(f"Files scanned: {len(python_files)}")
    print(f"Files {'modified' if args.apply else 'to modify'}: {total_changed}")
    print(f"Lines {'removed' if args.apply else 'to remove'}: {total_lines_removed}")
    
    if not args.apply and total_changed > 0:
        print(f"\n💡 To apply these changes, run:")
        print(f"   python delete_comments.py {args.path} --apply")
    
    print()


if __name__ == '__main__':
    main()
